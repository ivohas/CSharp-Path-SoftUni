﻿namespace Aquariums
{
    using System;

    public class StartUp
    {
       
    }
}
